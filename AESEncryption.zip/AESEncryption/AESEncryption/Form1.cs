﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;

namespace AESEncryption
{
    public partial class Form1 : Form
    {
        // nustato IV, tai ir apdaro kad jis nesikeistu
        private static byte[] IV = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        public Form1()
        {
            InitializeComponent();
        }
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private string Encrypt(string plainText, string Password, byte[] IV)
        {
            byte[] Key = Encoding.UTF8.GetBytes(Password);

            // inicalizuoja AesManaged   
            AesManaged aes = new AesManaged();
            aes.Key = Key;
            aes.IV = IV;

            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, aes.CreateEncryptor(), CryptoStreamMode.Write);

            byte[] InputBytes = Encoding.UTF8.GetBytes(plainText);
            cryptoStream.Write(InputBytes, 0, InputBytes.Length);
            cryptoStream.FlushFinalBlock();

            byte[] Encrypted = memoryStream.ToArray();

            // Grazina string kriptuota teksta
            return Convert.ToBase64String(Encrypted);
        }
        private void buttonEncrypt_Click(object sender, EventArgs e)
        {
            try
            { // paduoda zmogaus ivesta teksta ir pasworda
                textBoxEncryptedOutput.Text = Encrypt(textBoxInput.Text, textBoxEncryptPassword.Text, IV);
            }
            catch (Exception ex)
            { // jei klaida, ismeta error
                MessageBox.Show(ex.Message);
            }
        }
        private string Decrypt(string plaintext, string Password, byte[] IV)
        {
            byte[] Key = Encoding.UTF8.GetBytes(Password);

            // inicalizuoja AesManaged    
            AesManaged aes = new AesManaged();
            aes.Key = Key;
            aes.IV = IV;

            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, aes.CreateDecryptor(), CryptoStreamMode.Write);

            byte[] InputBytes = Convert.FromBase64String(plaintext);
            cryptoStream.Write(InputBytes, 0, InputBytes.Length);
            cryptoStream.FlushFinalBlock();

            byte[] Decrypted = memoryStream.ToArray();

            // Grazina string dekriptuota teksta
            return UTF8Encoding.UTF8.GetString(Decrypted, 0, Decrypted.Length);
        }
        private void buttonDecrypt_Click(object sender, EventArgs e)
        {
            try
            { // paduoda zmogaus ivesta teksta ir pasworda
                textBoxDecryptOutput.Text = Decrypt(textBoxEncrypted.Text, textBoxDcryptPassword.Text, IV);
            }
            catch (Exception ex)
            { // jei klaida, ismeta error
                MessageBox.Show(ex.Message);
            }
        }
        private void textBoxEncryptPassword_Leave(object sender, EventArgs e)
        { // kai pelytew nueini nuo lango ir neatitinka if
            if (((TextBox)sender).Text.Length != 16)
            {
                MessageBox.Show("Raktui reikia ne maziau 16 simboliu.");
            }
        }
        private void buttonClean_Click(object sender, EventArgs e)
        {
            textBoxInput.Clear();
            textBoxEncryptPassword.Clear();
            textBoxEncryptedOutput.Clear();
            textBoxEncrypted.Clear();
            textBoxDcryptPassword.Clear();
            textBoxDecryptOutput.Clear();
        }
    }
}
